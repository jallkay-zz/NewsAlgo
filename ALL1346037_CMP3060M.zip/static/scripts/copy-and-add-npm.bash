rm npm/*
cp slick.core.js npm/
cp slick.dataview.js npm/
cp slick.grid.js npm/
git apply scripts/add-npm.patch